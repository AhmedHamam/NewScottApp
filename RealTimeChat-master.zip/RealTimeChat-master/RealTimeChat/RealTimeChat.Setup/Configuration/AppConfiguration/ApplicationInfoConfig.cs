﻿namespace RealTimeChat.Setup.Configuration.AppConfiguration;

public class ApplicationInfoConfig
{
    public string? LogoUrl { get; set; }
    public string? SupportEmail { get; set; }
}