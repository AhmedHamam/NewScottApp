﻿namespace Base.API.Services.ElasticSearch.Models.Config;

/// <summary>
/// 
/// </summary>
public sealed class ElasticSearchConfig
{
    /// <summary>
    /// 
    /// </summary>
    public string? Url { get; set; }
}