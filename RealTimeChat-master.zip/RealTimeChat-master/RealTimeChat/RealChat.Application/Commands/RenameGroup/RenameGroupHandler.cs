﻿namespace RealChat.Application.Commands.RenameGroup
{
    public class RenameGroupHandler
    {
    }
}
