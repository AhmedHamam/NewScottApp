﻿namespace RealChat.Application.Commands.SendPrivateMessage
{
    public class SendPrivateMessageHandler
    {
    }
}
