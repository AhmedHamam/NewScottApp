﻿namespace RealChat.Application.Commands.SendPrivateMessage
{
    public class SendPrivateMessageValidator
    {
    }
}
