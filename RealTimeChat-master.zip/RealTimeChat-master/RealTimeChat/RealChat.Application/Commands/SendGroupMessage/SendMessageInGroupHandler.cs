﻿namespace RealChat.Application.Commands.SendGroupMessage
{
    public class SendMessageInGroupHandler
    {
    }
}
