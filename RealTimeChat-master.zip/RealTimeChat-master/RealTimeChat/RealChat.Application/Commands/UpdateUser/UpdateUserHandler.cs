﻿namespace RealChat.Application.Commands.UpdateUser
{
    public class UpdateUserHandler
    {
    }
}
