﻿namespace RealChat.Application.Commands.UpdateUser
{
    public class UpdateUserValidator
    {
    }
}
