﻿namespace RealChat.Application.Commands.ForgetPassword
{
    public class ForgetPasswordValidator
    {
    }
}
