﻿using MediatR;

namespace RealChat.Application.Commands.ForgetPassword
{
    public class ForgetPasswordCommand : IRequest<string>
    {
    }
}
