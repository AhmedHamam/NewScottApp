﻿namespace RealChat.Application.Commands.LeaveGroup
{
    public class LeaveGroupValidator
    {
    }
}
