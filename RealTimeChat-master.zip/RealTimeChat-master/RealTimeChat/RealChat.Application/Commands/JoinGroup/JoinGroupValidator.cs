﻿namespace RealChat.Application.Commands.JoinGroup
{
    public class JoinGroupCommandValidator
    {
    }
}
