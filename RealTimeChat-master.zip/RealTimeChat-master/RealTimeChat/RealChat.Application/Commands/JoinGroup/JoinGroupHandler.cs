﻿namespace RealChat.Application.Commands.JoinGroup
{
    public class JoinGroupCommandHandler
    {
    }
}
