﻿namespace RealChat.Application.Commands.JoinGroup
{
    public class JoinGroupCommand
    {
    }
}
