﻿namespace RealChat.Application.Commands.CreateGroup
{
    public class CreateGroupHandler
    {
    }
}
