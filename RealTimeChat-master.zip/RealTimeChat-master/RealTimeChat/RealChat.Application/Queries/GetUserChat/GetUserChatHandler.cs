﻿namespace RealChat.Application.Queries.GetUserChat
{
    public class GetUserChatHandler
    {
    }
}
