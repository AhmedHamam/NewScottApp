﻿namespace RealChat.Application.Queries.GetAllUsers
{
    public class GetAllUsersHandler
    {
    }
}
