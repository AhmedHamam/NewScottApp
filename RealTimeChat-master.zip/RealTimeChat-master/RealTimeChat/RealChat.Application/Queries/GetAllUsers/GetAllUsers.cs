﻿namespace RealChat.Application.Queries.GetAllUsers
{
    public class GetAllUsers
    {
    }
}
