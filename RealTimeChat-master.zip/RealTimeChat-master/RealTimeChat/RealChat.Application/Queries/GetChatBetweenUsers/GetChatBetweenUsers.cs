﻿namespace RealChat.Application.Queries.GetChatBetweenUsers
{
    public class GetChatBetweenUsers
    {
    }
}
