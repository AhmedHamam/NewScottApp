﻿namespace RealChat.Application.Queries.GetAllGroups
{
    public class GetAllGroupsHandler
    {
    }
}
