﻿namespace RealChat.Application.Queries.GetGroupChat
{
    public class GetGroupChatHandler
    {
    }
}
