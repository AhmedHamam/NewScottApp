﻿namespace RealChat.Application.Queries.GetUsersOfGroups
{
    public class GetUsersOfGroups
    {
    }
}
