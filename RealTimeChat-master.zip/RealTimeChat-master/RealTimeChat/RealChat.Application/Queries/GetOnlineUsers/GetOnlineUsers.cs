﻿namespace RealChat.Application.Queries.GetOnlineUsers
{
    public class GetOnlineUsers
    {
    }
}
