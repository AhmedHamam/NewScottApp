﻿namespace RealChat.Application.Queries.GetCurrentUserGroups
{
    public class GetCurrentUserGroupsHandler
    {
    }
}
