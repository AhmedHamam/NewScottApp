namespace Base.Application.Interfaces;

public interface ICacheableQuery
{
}