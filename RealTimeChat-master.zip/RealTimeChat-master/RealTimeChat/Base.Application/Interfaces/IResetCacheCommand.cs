namespace Base.Application.Interfaces;

public interface IResetCacheCommand
{
}