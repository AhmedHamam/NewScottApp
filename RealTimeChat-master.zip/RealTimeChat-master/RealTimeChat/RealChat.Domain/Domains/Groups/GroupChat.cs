﻿using Base.Domain.CommonModels;

namespace RealChat.Domain.Domains.Groups
{
    public class GroupChat : BaseEntity<int>
    {
    }
}
